import express from "express";
import path from "path";
import {fileURLToPath} from "url";

const app=express();
const __dirname=path.dirname(fileURLToPath(import.meta.url));
const PORT=process.env.PORT||3000;
const KEY=process.env.API_FOOTBALL_KEY;
const BASE="https://v3.football.api-sports.io";

async function api(endpoint){
  if(!KEY) return {error:"API_FOOTBALL_KEY non configurata"};
  const r=await fetch(BASE+endpoint,{headers:{"x-apisports-key":KEY}});
  return await r.json();
}

app.get("/api/live",async(req,res)=>{
  try{res.json(await api("/fixtures?live=all"));}catch(e){res.status(500).json({error:e.message});}
});
app.get("/api/fixtures",async(req,res)=>{
  try{
    const date=req.query.date || new Date().toISOString().slice(0,10);
    res.json(await api(`/fixtures?date=${encodeURIComponent(date)}&timezone=Europe/Rome`));
  }catch(e){res.status(500).json({error:e.message});}
});
app.get("/api/statistics/:id",async(req,res)=>{
  try{res.json(await api(`/fixtures/statistics?fixture=${encodeURIComponent(req.params.id)}`));}
  catch(e){res.status(500).json({error:e.message});}
});
app.get("/api/standings/:league/:season",async(req,res)=>{
  try{res.json(await api(`/standings?league=${req.params.league}&season=${req.params.season}`));}
  catch(e){res.status(500).json({error:e.message});}
});

app.use(express.static(path.join(__dirname,"dist")));
app.get("*",(req,res)=>res.sendFile(path.join(__dirname,"dist","index.html")));

app.listen(PORT,()=>console.log(`CalcioStats su http://localhost:${PORT}`));
