import express from "express";

const app = express();
const PORT = process.env.PORT || 3000;
const KEY = process.env.API_FOOTBALL_KEY;
const API = "https://v3.football.api-sports.io";

async function football(path) {
  if (!KEY) return { error: "API_FOOTBALL_KEY non configurata" };
  const r = await fetch(API + path, { headers: { "x-apisports-key": KEY } });
  return await r.json();
}

app.get("/api/fixtures", async (req,res) => {
  const date = req.query.date || new Date().toISOString().slice(0,10);
  res.json(await football(`/fixtures?date=${date}&timezone=Europe/Rome`));
});
app.get("/api/live", async (req,res) => res.json(await football("/fixtures?live=all")));
app.get("/api/statistics/:id", async (req,res) =>
  res.json(await football(`/fixtures/statistics?fixture=${req.params.id}`))
);

app.get("/", (_,res)=>res.type("html").send(PAGE));
app.listen(PORT,()=>console.log("CalcioStats: http://localhost:"+PORT));

const PAGE = `<!doctype html>
<html lang="it"><head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<meta name="theme-color" content="#080c11"><title>CalcioStats</title>
<style>
*{box-sizing:border-box}body{margin:0;background:#080c11;color:#f4f6f8;font-family:-apple-system,BlinkMacSystemFont,"SF Pro Display",Arial,sans-serif}
header{height:68px;padding:0 18px;display:flex;align-items:center;justify-content:space-between;border-bottom:1px solid #202833;background:#0d1218;position:sticky;top:0;z-index:4}
header b{font-size:21px}header span{font-size:9px;color:#6fe0c7;border:1px solid #28564e;padding:6px 8px;border-radius:20px}
main{max-width:760px;margin:auto;padding:22px 16px 100px}.hero{display:flex;justify-content:space-between;align-items:center;margin-bottom:18px}
.hero small{color:#8995a3}.hero h1{margin:5px 0;font-size:29px}.hero p{margin:0;color:#84909e;font-size:13px}
button{font:inherit;color:inherit;border:0;cursor:pointer}.refresh{background:#151c24;border:1px solid #27313c;border-radius:12px;padding:11px 14px}
.filters{display:flex;gap:8px;overflow:auto;margin-bottom:14px}.filters button{white-space:nowrap;background:#151b23;border:1px solid #252f3a;padding:9px 12px;border-radius:20px;font-size:12px}
.card{display:block;width:100%;background:#11171f;border:1px solid #202a35;border-radius:17px;padding:16px;margin:10px 0;text-align:left}.top{display:flex;justify-content:space-between;color:#83909f;font-size:11px}
.live{color:#ff6773}.teams{display:grid;grid-template-columns:1fr auto 1fr;gap:12px;align-items:center;text-align:center;margin:18px 0 8px}.teams strong{font-size:20px}.more{color:#7f8c9b;font-size:11px;text-align:right}
.empty,.error{padding:28px;text-align:center;color:#8995a3;background:#11171f;border-radius:17px;margin-top:12px}.error{color:#ffb2b8}
.detailTeams{display:grid;grid-template-columns:1fr auto 1fr;align-items:center;text-align:center;gap:15px;margin-top:18px}.detailTeams strong{font-size:28px}
.stat{padding:12px 0;border-bottom:1px solid #202833}.stat>div{display:grid;grid-template-columns:70px 1fr 70px;text-align:center;gap:8px}.stat span{color:#8995a3;font-size:12px}
nav{position:fixed;bottom:0;left:0;right:0;height:72px;background:#0d1218ed;border-top:1px solid #202833;display:flex;justify-content:center;z-index:8}
nav button{background:none;color:#6e7b8a;width:25%;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:5px;font-size:17px}nav button span{font-size:10px}nav .on{color:#fff}
@media(min-width:700px){nav{width:680px;left:50%;right:auto;transform:translateX(-50%);border:1px solid #202833;border-radius:18px;bottom:15px}}
</style></head><body>
<header><b>⚽ CalcioStats</b><span>DATI REALI</span></header><main id="app"></main>
<nav><button class="on" onclick="home()">⌂<span>Home</span></button><button onclick="live()">🔴<span>Live</span></button><button onclick="home()">📅<span>Partite</span></button><button onclick="leagues()">🏆<span>Campionati</span></button></nav>
<script>
const leagues=[["🇮🇹","Serie A"],["🏆","Champions League"],["🏴","Premier League"],["🇪🇸","La Liga"]];
const app=document.getElementById("app");
function esc(s){return String(s||"").replace(/[&<>"]/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"}[c]))}
function card(g){let s=g.score||{},status=g.fixture.status;let t=status.short==="NS"?new Date(g.fixture.date).toLocaleTimeString("it-IT",{hour:"2-digit",minute:"2-digit"}):status.short;
return \`<button class="card" onclick="detail(\${g.fixture.id})"><div class="top"><span>⚽ \${esc(g.league?.name)}</span><b class="\${status.elapsed?'live':''}">\${t}</b></div><div class="teams"><span>\${esc(g.teams.home.name)}</span><strong>\${s.full?.home??"-"} - \${s.full?.away??"-"}</strong><span>\${esc(g.teams.away.name)}</span></div><div class="more">Statistiche partita →</div></button>\`}
async function home(){app.innerHTML=\`<div class="hero"><div><small>OGGI</small><h1>Partite di calcio</h1><p>Risultati e statistiche aggiornati.</p></div><button class="refresh" onclick="home()">↻</button></div><div class="filters">\${leagues.map(x=>"<button>"+x[0]+" "+x[1]+"</button>").join("")}</div><div class="empty">Caricamento…</div>\`;
try{let d=await fetch("/api/fixtures").then(r=>r.json());if(d.error)throw Error(d.error);app.innerHTML=app.innerHTML.replace('<div class="empty">Caricamento…</div>',d.response?.length?d.response.map(card).join(""):'<div class="empty">Nessuna partita disponibile oggi.</div>')}catch(e){app.innerHTML+=\`<div class="error">⚠️ \${esc(e.message)}</div>\`}}
async function live(){app.innerHTML="<h1>🔴 Partite Live</h1><div class='empty'>Caricamento…</div>";try{let d=await fetch("/api/live").then(r=>r.json());app.innerHTML="<h1>🔴 Partite Live</h1>"+(d.response?.length?d.response.map(card).join(""):"<div class='empty'>Nessuna partita live al momento.</div>")}catch(e){app.innerHTML+="<div class='error'>Errore nel caricamento.</div>"}}
function leagues(){app.innerHTML="<h1>🏆 Campionati</h1>"+leagues.map(x=>\`<div class="card"><b>\${x[0]} \${x[1]}</b><div class="more">Classifica e statistiche →</div></div>\`).join("")}
async function detail(id){app.innerHTML="<div class='empty'>Caricamento statistiche…</div>";try{let d=await fetch("/api/statistics/"+id).then(r=>r.json());let s=d.response||[];let map={};(s[0]?.statistics||[]).forEach(x=>map[x.type]=[x.value,null]);(s[1]?.statistics||[]).forEach(x=>(map[x.type]??=[null,null])[1]=x.value);app.innerHTML="<button onclick='home()'>← Torna alle partite</button><section class='card'><h2>📊 Statistiche partita</h2>"+(Object.entries(map).map(([k,v])=>\`<div class="stat"><div><b>\${v[0]??"-"}</b><span>\${esc(k)}</span><b>\${v[1]??"-"}</b></div></div>\`).join("")||"<p>Statistiche non ancora disponibili.</p>")+"</section>"}catch(e){app.innerHTML="<div class='error'>Errore nel caricamento delle statistiche.</div>"}}
home();
</script></body></html>`;
