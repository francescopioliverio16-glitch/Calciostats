# CalcioStats — versione con dati reali

Questa versione usa API-Football lato server, così la API key non viene messa nel JavaScript pubblico.

## Configurazione
1. Copia `.env.example` in `.env`
2. Inserisci la NUOVA API key in `API_FOOTBALL_KEY`
3. `npm install`
4. `npm run dev`

Per pubblicarla online serve un hosting che esegua Node.js (es. Vercel/Render/Railway). Imposta lì `API_FOOTBALL_KEY` come Environment Variable.

## Campionati
- Serie A: 135
- Champions League: 2
- Premier League: 39
- La Liga: 140

Le chiamate principali sono:
- `/fixtures?date=YYYY-MM-DD`
- `/fixtures?live=all`
- `/fixtures/statistics?fixture=ID`
- `/standings?league=ID&season=2026`

Non inserire mai la API key nel codice frontend o in un repository pubblico.
