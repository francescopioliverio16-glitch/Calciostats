import React,{useEffect,useState} from "react";
import {createRoot} from "react-dom/client";
import "./styles.css";

const leagues=[
 {id:135,name:"Serie A",flag:"🇮🇹"},
 {id:2,name:"Champions League",flag:"🏆"},
 {id:39,name:"Premier League",flag:"🏴"},
 {id:140,name:"La Liga",flag:"🇪🇸"}
];

function App(){
 const [view,setView]=useState("home"),[games,setGames]=useState([]),[selected,setSelected]=useState(null),[stats,setStats]=useState(null),[loading,setLoading]=useState(true),[err,setErr]=useState("");
 const load=async()=>{setLoading(true);setErr("");try{const r=await fetch("/api/fixtures");const d=await r.json();if(d.error)throw Error(d.error);setGames(d.response||[])}catch(e){setErr(e.message)}finally{setLoading(false)}};
 useEffect(()=>{load()},[]);
 const open=async(g)=>{setSelected(g);setStats(null);try{const r=await fetch("/api/statistics/"+g.fixture.id);const d=await r.json();setStats(d.response||[])}catch{}};
 return <><header><b>⚽ CalcioStats</b><span>LIVE • DATI REALI</span></header>
 <main>
  {view==="home"&&<><section className="hero"><div><small>OGGI</small><h1>Partite di calcio</h1><p>Risultati e statistiche aggiornati dall'API.</p></div><button onClick={load}>↻</button></section>
  <div className="leagueRow">{leagues.map(l=><button key={l.id}>{l.flag} {l.name}</button>)}</div>
  {err&&<div className="error">⚠️ {err}<br/><small>Configura API_FOOTBALL_KEY nel server.</small></div>}
  {loading?<div className="empty">Caricamento partite…</div>:games.length===0?<div className="empty">Nessuna partita disponibile per oggi.</div>:games.map(g=><Game key={g.fixture.id} g={g} onClick={()=>open(g)}/>)}</>}
  {view==="live"&&<Live/>}
  {view==="leagues"&&<LeagueList/>}
  {selected&&<Detail g={selected} stats={stats} close={()=>{setSelected(null);setStats(null)}}/>}
 </main>
 <nav><button className={view==="home"?"on":""} onClick={()=>setView("home")}>⌂<span>Home</span></button><button className={view==="live"?"on":""} onClick={()=>setView("live")}>🔴<span>Live</span></button><button onClick={()=>setView("home")}>📅<span>Partite</span></button><button className={view==="leagues"?"on":""} onClick={()=>setView("leagues")}>🏆<span>Campionati</span></button></nav>
 </>;
}

function Game({g,onClick}){let s=g.score||{};return <button className="card" onClick={onClick}><div className="top"><span>{g.league?.flag||"⚽"} {g.league?.name}</span><b className={g.fixture.status.short==="LIVE"||g.fixture.status.elapsed?"live":""}>{g.fixture.status.short==="NS"?new Date(g.fixture.date).toLocaleTimeString("it-IT",{hour:"2-digit",minute:"2-digit"}):g.fixture.status.short}</b></div><div className="teams"><span>{g.teams.home.name}</span><strong>{s.full?.home??"-"} - {s.full?.away??"-"}</strong><span>{g.teams.away.name}</span></div><div className="more">Statistiche partita →</div></button>}

function Detail({g,stats,close}){return <div className="modal"><button className="back" onClick={close}>← Torna alle partite</button><section className="card detail"><small>{g.league.name}</small><div className="detailTeams"><b>{g.teams.home.name}</b><strong>{g.score.full?.home??0} - {g.score.full?.away??0}</strong><b>{g.teams.away.name}</b></div></section><section className="card"><h2>📊 Statistiche</h2>{!stats?<p>Caricamento…</p>:stats.length===0?<p>Statistiche non ancora disponibili.</p>:<Stats data={stats}/>}</section></div>}

function Stats({data}){let h=data[0]?.statistics||[],a=data[1]?.statistics||[];let map={};h.forEach(x=>map[x.type]=[x.value,null]);a.forEach(x=>{if(map[x.type])map[x.type][1]=x.value;else map[x.type]=[null,x.value]});return <>{Object.entries(map).map(([k,v])=><div className="stat" key={k}><div><b>{v[0]??"-"}</b><span>{k}</span><b>{v[1]??"-"}</b></div></div>)}</>}

function Live(){const [live,setLive]=useState(null);useEffect(()=>{fetch("/api/live").then(r=>r.json()).then(d=>setLive(d.response||[]))},[]);return <section><h1>🔴 Partite Live</h1>{live?.length?live.map(g=><Game key={g.fixture.id} g={g} onClick={()=>{}}/>):<div className="empty">Nessuna partita live al momento.</div>}</section>}
function LeagueList(){return <section><h1>🏆 Campionati</h1>{leagues.map(l=><div className="leagueCard" key={l.id}>{l.flag} <b>{l.name}</b><span>Statistiche e classifica →</span></div>)}</section>}

createRoot(document.getElementById("root")).render(<App/>);